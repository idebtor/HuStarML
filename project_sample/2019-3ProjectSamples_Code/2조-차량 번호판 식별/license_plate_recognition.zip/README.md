# 번호판 인식 (차량 번호판 인식기)




# 필요
- Python 3+
- pytesseract 4.0
- OpenCV
- numpy
- matplotlib

1. OCR 다운로드 및 설치
- https://github.com/tesseract-ocr/tesseract/wiki/4.0-with-LSTM#400-alpha-for-windows Windows Installer made with MinGW-w64 설치

  https://niceman.tistory.com/155 설치 방법

2.pip install opencv-python
3.pip install pytesseract

